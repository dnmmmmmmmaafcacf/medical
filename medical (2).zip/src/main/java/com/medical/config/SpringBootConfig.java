package com.medical.config;

import org.springframework.boot.web.embedded.undertow.UndertowServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: JiaJieTang
 * @Date: 2022/8/9 16:14
 * @Description:
 */
//@Configuration
//public class SpringBootConfig {
//    @Bean
//    public ServletWebServerFactory servletContainer(){
//        UndertowServletWebServerFactory undertow = new UndertowServletWebServerFactory();
//        return undertow;
//    }
//}
