package com.medical.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.medical.entity.Vip;

public interface VipMapper extends BaseMapper<Vip> {
}
