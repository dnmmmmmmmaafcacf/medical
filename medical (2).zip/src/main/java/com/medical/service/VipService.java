package com.medical.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.medical.entity.Vip;

public interface VipService extends IService<Vip> {
}
